// #include "TrackItem.h"

// // === File: TrackItem.cpp ===
// #include "TrackItem.h"

// TreeItem::TreeItem(const QVariantMap &data, TreeItem *parent)
//     : m_data(data), m_parentItem(parent) {}

// TreeItem::~TreeItem() {
//     qDeleteAll(m_childItems);
// }

// // void TreeItem::appendChild(TreeItem *child) {
// //     m_childItems.append(child);
// // }

// void TreeItem::appendChild(TreeItem *child) {
//     child->m_parentItem = this;
//     m_childItems.append(child);
// }

// TreeItem *TreeItem::child(int row) {
//     return m_childItems.value(row);
// }

// int TreeItem::childCount() const {
//     return m_childItems.size();
// }

// QVariantMap TreeItem::data() const {
//     return m_data;
// }

// int TreeItem::row() const {
//     if (m_parentItem)
//         return m_parentItem->m_childItems.indexOf(const_cast<TreeItem*>(this));
//     return 0;
// }

// int TreeItem::depth() const {
//     int d = 0;
//     TreeItem *current = m_parentItem;
//     while (current) {
//         d++;
//         current = current->m_parentItem;
//     }
//     return d;
// }

// TreeItem *TreeItem::parentItem() {
//     return m_parentItem;
// }


#include "TrackItem.h"

TreeItem::TreeItem(const QVariantMap &data, TreeItem *parent)
    : m_data(data), m_parentItem(parent) {}

TreeItem::~TreeItem() {
    qDeleteAll(m_childItems);
}

void TreeItem::appendChild(TreeItem *child) {
    child->m_parentItem = this;
    m_childItems.append(child);
}

TreeItem *TreeItem::child(int row) const {
    return (row >= 0 && row < m_childItems.size()) ? m_childItems.at(row) : nullptr;
}

int TreeItem::childCount() const {
    return m_childItems.size();
}

int TreeItem::row() const {
    if (m_parentItem)
        return m_parentItem->m_childItems.indexOf(const_cast<TreeItem *>(this));
    return 0;
}

TreeItem *TreeItem::parentItem() const {
    return m_parentItem;
}

QVariantMap TreeItem::data() const {
    return m_data;
}

int TreeItem::depth() const {
    int d = 0;
    const TreeItem *p = m_parentItem;
    while (p) {
        d++;
        p = p->parentItem();
    }
    return d;
}

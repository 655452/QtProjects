#ifndef TRACKFILTERMODEL_H
#define TRACKFILTERMODEL_H

// TrackFilterModel.h
#pragma once

#include <QSortFilterProxyModel>
#include <QString>

// class TrackFilterModel : public QSortFilterProxyModel {
//     Q_OBJECT
//     Q_PROPERTY(QString type READ type WRITE setType NOTIFY filterChanged)
//     Q_PROPERTY(QString sensor READ sensor WRITE setSensor NOTIFY filterChanged)
//     Q_PROPERTY(QString category READ category WRITE setCategory NOTIFY filterChanged)

// public:
//     explicit TrackFilterModel(QObject *parent = nullptr);

//     QString type() const { return m_type; }
//     QString sensor() const { return m_sensor; }
//     QString category() const { return m_category; }

//     void setType(const QString &type);
//     void setSensor(const QString &sensor);
//     void setCategory(const QString &category);

// signals:
//     void filterChanged();

// protected:
//     bool filterAcceptsRow(int sourceRow, const QModelIndex &sourceParent) const override;

// private:
//     QString m_type;
//     QString m_sensor;
//     QString m_category;
// };

#include <QSortFilterProxyModel>

class TrackFilterModel : public QSortFilterProxyModel {
    Q_OBJECT
    Q_PROPERTY(QString type READ type WRITE setType NOTIFY filterChanged)
    Q_PROPERTY(QString sensor READ sensor WRITE setSensor NOTIFY filterChanged)
    Q_PROPERTY(QString category READ category WRITE setCategory NOTIFY filterChanged)

public:
    explicit TrackFilterModel(QObject *parent = nullptr);

    QString type() const;
    QString sensor() const;
    QString category() const;

    void setType(const QString &type);
    void setSensor(const QString &sensor);
    void setCategory(const QString &category);

signals:
    void filterChanged();

protected:
    bool filterAcceptsRow(int sourceRow, const QModelIndex &sourceParent) const override;
    QHash<int, QByteArray> roleNames() const override;

private:
    QString m_type;
    QString m_sensor;
    QString m_category;
};

#endif // TRACKFILTERMODEL_H

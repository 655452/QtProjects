// // // TrackFilterModel.cpp
// // #include "TrackFilterModel.h"
// // #include <QAbstractItemModel>

// // TrackFilterModel::TrackFilterModel(QObject *parent)
// //     : QSortFilterProxyModel(parent) {
// //     setRecursiveFilteringEnabled(true);
// //     setFilterCaseSensitivity(Qt::CaseInsensitive);
// // }

// // void TrackFilterModel::setType(const QString &type) {
// //     if (m_type != type) {
// //         m_type = type;
// //         invalidateFilter();
// //         emit filterChanged();
// //     }
// // }

// // void TrackFilterModel::setSensor(const QString &sensor) {
// //     if (m_sensor != sensor) {
// //         m_sensor = sensor;
// //         invalidateFilter();
// //         emit filterChanged();
// //     }
// // }

// // void TrackFilterModel::setCategory(const QString &category) {
// //     if (m_category != category) {
// //         m_category = category;
// //         invalidateFilter();
// //         emit filterChanged();
// //     }
// // }

// // bool TrackFilterModel::filterAcceptsRow(int sourceRow, const QModelIndex &sourceParent) const {
// //     QModelIndex idx = sourceModel()->index(sourceRow, 0, sourceParent);
// //     if (!idx.isValid())
// //         return false;

// //     auto data = idx.data(Qt::UserRole + 4).toMap();
// //     if (!m_type.isEmpty() && data.value("type") != m_type)
// //         return false;
// //     if (!m_sensor.isEmpty() && data.value("sensor") != m_sensor)
// //         return false;
// //     if (!m_category.isEmpty() && data.value("category") != m_category)
// //         return false;

// //     return true;
// // }


// // QHash<int, QByteArray> TrackFilterModel::roleNames() const {
// //     if (sourceModel())
// //         return sourceModel()->roleNames();
// //     return QSortFilterProxyModel::roleNames();
// // }


// #include "TrackFilterModel.h"
// #include <QDebug>

// TrackFilterModel::TrackFilterModel(QObject *parent)
//     : QSortFilterProxyModel(parent),
//     m_type(""),
//     m_sensor(""),
//     m_category("")
// {
//     setRecursiveFilteringEnabled(true);
//     setFilterCaseSensitivity(Qt::CaseInsensitive);
// }

// QString TrackFilterModel::type() const {
//     return m_type;
// }

// QString TrackFilterModel::sensor() const {
//     return m_sensor;
// }

// QString TrackFilterModel::category() const {
//     return m_category;
// }

// void TrackFilterModel::setType(const QString &type) {
//     if (m_type != type) {
//         m_type = type;
//         invalidateFilter();
//         emit filterChanged();
//     }
// }

// void TrackFilterModel::setSensor(const QString &sensor) {
//     if (m_sensor != sensor) {
//         m_sensor = sensor;
//         invalidateFilter();
//         emit filterChanged();
//     }
// }

// void TrackFilterModel::setCategory(const QString &category) {
//     if (m_category != category) {
//         m_category = category;
//         invalidateFilter();
//         emit filterChanged();
//     }
// }

// bool TrackFilterModel::filterAcceptsRow(int sourceRow, const QModelIndex &sourceParent) const {
//     QModelIndex idx = sourceModel()->index(sourceRow, 0, sourceParent);
//     if (!idx.isValid())
//         return false;

//     QVariantMap data = idx.data(Qt::UserRole + 4).toMap(); // fullData

//     // Debug: log filtering process
//     qDebug() << "[FilterModel] Filtering track:" << data.value("id").toString()
//              << "Sensor:" << data.value("sensor").toString()
//              << "Type:" << data.value("type").toString()
//              << "Category:" << data.value("category").toString();

//     if (!m_type.isEmpty() && data.value("type").toString() != m_type)
//         return false;

//     if (!m_sensor.isEmpty() && data.value("sensor").toString() != m_sensor)
//         return false;

//     if (!m_category.isEmpty() && data.value("category").toString() != m_category)
//         return false;

//     return true;
// }

// QHash<int, QByteArray> TrackFilterModel::roleNames() const {
//     if (sourceModel())
//         return sourceModel()->roleNames();
//     return QSortFilterProxyModel::roleNames();
// }



#include "TrackFilterModel.h"
#include <QAbstractItemModel>
#include <QDebug>

TrackFilterModel::TrackFilterModel(QObject *parent)
    : QSortFilterProxyModel(parent) {
    setDynamicSortFilter(true);
    setRecursiveFilteringEnabled(true);
    setFilterCaseSensitivity(Qt::CaseInsensitive);
}

QString TrackFilterModel::type() const { return m_type; }
QString TrackFilterModel::sensor() const { return m_sensor; }
QString TrackFilterModel::category() const { return m_category; }

void TrackFilterModel::setType(const QString &type) {
    if (m_type != type) {
        m_type = type;
        invalidateFilter();
        emit filterChanged();
    }
}

void TrackFilterModel::setSensor(const QString &sensor) {
    if (m_sensor != sensor) {
        m_sensor = sensor;
        invalidateFilter();
        emit filterChanged();
    }
}

void TrackFilterModel::setCategory(const QString &category) {
    if (m_category != category) {
        m_category = category;
        invalidateFilter();
        emit filterChanged();
    }
}

bool TrackFilterModel::filterAcceptsRow(int sourceRow, const QModelIndex &sourceParent) const {
    QModelIndex idx = sourceModel()->index(sourceRow, 0, sourceParent);
    if (!idx.isValid())
        return false;

    auto data = idx.data(Qt::UserRole + 4).toMap(); // fullData

    qDebug() << "[FilterModel] Filtering track:" << data.value("id").toString()
             << "Sensor:" << data.value("sensor").toString()
             << "Type:" << data.value("type").toString()
             << "Category:" << data.value("category").toString();

    return (m_type.isEmpty() || data.value("type") == m_type) &&
           (m_sensor.isEmpty() || data.value("sensor") == m_sensor) &&
           (m_category.isEmpty() || data.value("category") == m_category);
}

QHash<int, QByteArray> TrackFilterModel::roleNames() const {
    if (sourceModel())
        return sourceModel()->roleNames();
    return QSortFilterProxyModel::roleNames();
}

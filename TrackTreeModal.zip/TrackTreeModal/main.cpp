#include <QGuiApplication>
#include <QQmlApplicationEngine>

#include <TrackFilterModel.h>
#include <TrackTreeModel.h>
#include <TrackManager.h>
#include <QQmlContext>

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    qmlRegisterType<TrackTreeModel>("App.Models", 1, 0, "TrackTreeModel");
    qmlRegisterType<TrackFilterModel>("App.Models", 1, 0, "TrackFilterModel");

    TrackTreeModel model;
    TrackManager simulator;
    simulator.setTrackModel(&model);

    engine.rootContext()->setContextProperty("trackModel", &model);
    engine.rootContext()->setContextProperty("trackSimulator", &simulator);

    QObject::connect(
        &engine,
        &QQmlApplicationEngine::objectCreationFailed,
        &app,
        []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);
    engine.loadFromModule("TrackTreeModal", "Main");

    return app.exec();
}

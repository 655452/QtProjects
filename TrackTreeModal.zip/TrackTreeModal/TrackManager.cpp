// // // TrackManager.cpp
// #include "TrackManager.h"
// #include <QtGlobal>
// #include <QTime>
// TrackManager::TrackManager(QObject *parent)
//     : QObject(parent) {}

// void TrackManager::setTrackModel(TrackTreeModel *model) {
//     m_model = model;
// }

// void TrackManager::simulateTrack(const QString &sensor, const QString &type, const QString &category) {
//     if (!m_model)
//         return;

//     QVariantMap track {
//         {"id", QString("SIM_%1").arg(QDateTime::currentSecsSinceEpoch())},
//         {"type", type},
//         {"sensor", sensor},
//         {"category", category},
//         {"parameters", QVariantMap {
//                            {"bearing", rand() % 360},
//                            {"speed", 5 + (rand() % 30)},
//                            {"course", rand() % 360}
//                        }},
//         {"children", QVariantList()}
//     };

//     qDebug() << "track simulated " << QString("SIM_%1").arg(QDateTime::currentSecsSinceEpoch()) << sensor << type << category;
//     m_model->addTrackFromCpp(track);
// }


#include "TrackManager.h"
#include <QDateTime>
#include <QDebug>

TrackManager::TrackManager(QObject *parent)
    : QObject(parent)
{
    connect(&m_timer, &QTimer::timeout, this, &TrackManager::onTimerTimeout);
    startSimulation(1000);
}

void TrackManager::setTrackModel(TrackTreeModel *model) {
    m_model = model;
}

void TrackManager::simulateTrack(const QString &sensor, const QString &type, const QString &category) {
    if (!m_model)
        return;

    QVariantMap track {
        {"id", QString("SIM_%1").arg(QDateTime::currentSecsSinceEpoch())},
        {"type", type},
        {"sensor", sensor},
        {"category", category},
        {"parameters", QVariantMap {
                           {"bearing", rand() % 360},
                           {"speed", 5 + (rand() % 30)},
                           {"course", rand() % 360}
                       }},
        {"children", QVariantList()}
    };

    qDebug() << "Track simulated:" << track["id"].toString() << sensor << type << category;
    m_model->addTrackFromCpp(track);
}

void TrackManager::startSimulation(int intervalMs)
{
    m_timer.start(intervalMs); // e.g., 2000 for every 2 seconds
}

void TrackManager::onTimerTimeout()
{
    // You can change these to random or varying values if needed
    simulateTrack("Radar", "RAW", "UNKNOWN");
    qDebug() << "Simulated Track in Model";
}

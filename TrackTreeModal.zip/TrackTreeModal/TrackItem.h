// #ifndef TRACKITEM_H
// #define TRACKITEM_H

// === File: TrackItem.h ===
#pragma once

// #include <QVariant>
// #include <QList>

// class TreeItem {
// public:
//     explicit TreeItem(const QVariantMap &data, TreeItem *parentItem = nullptr);
//     ~TreeItem();

//     void appendChild(TreeItem *child);
//     TreeItem *child(int row);
//     int childCount() const;
//     QVariantMap data() const;
//     int row() const;
//     int depth() const;
//     TreeItem *parentItem();

// private:
//     QList<TreeItem*> m_childItems;
//     QVariantMap m_data;
//     TreeItem *m_parentItem;
// };

#ifndef TREEITEM_H
#define TREEITEM_H

#include <QVariantMap>
#include <QVector>

class TreeItem {
public:
    explicit TreeItem(const QVariantMap &data, TreeItem *parent = nullptr);
    ~TreeItem();

    void appendChild(TreeItem *child);
    TreeItem *child(int row) const;
    int childCount() const;
    int row() const;

    TreeItem *parentItem() const;
    QVariantMap data() const;
    int depth() const;

private:
    QVariantMap m_data;
    TreeItem *m_parentItem;
    QVector<TreeItem *> m_childItems;
};

#endif // TREEITEM_H

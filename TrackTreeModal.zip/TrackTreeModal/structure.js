// structure.js
var data = [
    {
        name: "RAW",
        sensors: ["Radar", "Sonar", "AIS", "DL", "Periscope"],
        categories: ["UNKNOWN", "SURFACE", "SUBSURFACE", "AIR", "MANUAL RAW"]
    },
    {
        name: "SENSOR",
        sensors: ["Radar", "Sonar", "AIS", "DL", "Periscope"],
        categories: ["UNKNOWN", "SURFACE", "SUBSURFACE", "AIR", "MANUAL"]
    },
    {
        name: "SYSTEM",
        sensors: [],
        categories: ["UNKNOWN", "SURFACE", "SUBSURFACE", "AIR"]
    }
];

#ifndef TRACKMANAGER_H
#define TRACKMANAGER_H

// #include <QObject>
// #include <QVariantMap>
// #include "TrackTreeModel.h"

// // TrackManager.h
// class TrackManager : public QObject {
//     Q_OBJECT
// public:
//     explicit TrackManager(QObject *parent = nullptr);

//     Q_INVOKABLE void simulateTrack(const QString &sensor, const QString &type, const QString &category);

//     void setTrackModel(TrackTreeModel *model);

// private:
//     TrackTreeModel *m_model = nullptr;
// };


#include <QObject>
#include <QVariantMap>
#include <QTimer>
#include "TrackTreeModel.h"

class TrackManager : public QObject
{
    Q_OBJECT
public:
    explicit TrackManager(QObject *parent = nullptr);

    void setTrackModel(TrackTreeModel *model);
    Q_INVOKABLE void simulateTrack(const QString &sensor,
                                   const QString &type,
                                   const QString &category);

    void startSimulation(int intervalMs); // Start automatic simulation

private slots:
    void onTimerTimeout(); // Called when timer times out

private:
    TrackTreeModel *m_model = nullptr;
    QTimer m_timer;
};

#endif // TRACKMANAGER_H

